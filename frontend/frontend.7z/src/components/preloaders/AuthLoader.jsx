import './preloader.css'
const AuthLoader = () => {
  return (
    <div className='loader-container'>
        <div className="spinner"></div>
    </div>
  )
}

export default AuthLoader