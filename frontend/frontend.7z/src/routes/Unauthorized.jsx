
const Unauthorized = () => {
  return (
    <div className="unauthorized">403 | Not authorized</div>
  )
}

export default Unauthorized